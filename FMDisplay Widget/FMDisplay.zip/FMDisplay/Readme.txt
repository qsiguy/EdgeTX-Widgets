FMDisplay widget for EdgeTX
===========================

Copy the contents of this folder to the transmitters SD card to /WIDGETS/FMDisplay

This widget reads the current radio Flight Mode and displays it on the screen in larger print with different background colors.

To change text size or mode background colors, manually edit the main.lua script.
