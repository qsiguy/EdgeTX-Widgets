---------------------------------------------------------------------------
--                                                                       --
--   Title: Flight Mode Display Widget "FMDisplay"                       --
--  Author: Shane Christopherson                                         --
--    Date: 2025-09-15                                                   --
-- Version: 1.0.0                                                        --
--  Source: https://github.com/qsiguy/EdgeTX-TX16S-Models                --
--          https://www.youtube.com/@shanesdiy                           --
--                                                                       --
-- Copyright (C): Shane Christopherson/Shane's DIY                        --
--                                                                       --
-- License GPLv2: http://www.gnu.org/licenses/gpl-2.0.html               --
--                                                                       --
-- This program is free software; you can redistribute it and/or modify  --
-- it under the terms of the GNU General Public License version 2 as     --
-- published by the Free Software Foundation.                            --
--                                                                       --
-- This program is distributed in the hope that it will be useful        --
-- but WITHOUT ANY WARRANTY; without even the implied warranty of        --
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the          --
-- GNU General Public License for more details.                          --
--                                                                       --
-- Put in /WIDGETS/FMDisplay/                                            --
---------------------------------------------------------------------------

local function create(zone, options)
  return { zone = zone, options = options }
end

local function update(widget, options)
  widget.options = options
end

local function refresh(widget)
  local x, y, w, h = widget.zone.x, widget.zone.y, widget.zone.w, widget.zone.h

  -- getFlightMode() returns (number, name)
  local fmNum, fmName = getFlightMode()
  if not fmName or fmName == "" then
    fmName = "FM" .. tostring(fmNum or 0)
  end

  -- Choose background color depending on mode number
  local bgColor = WHITE
  if fmNum == 0 then
    bgColor = GREEN   -- default mode
  elseif fmNum == 1 then
    bgColor = ORANGE  -- second mode
  elseif fmNum == 2 then
    bgColor = BLUE    -- third mode
  elseif fmNum == 3 then
    bgColor = GREY    -- fourth mode	
  else
    bgColor = RED     -- other modes
  end

  -- Draw background rectangle
  lcd.setColor(CUSTOM_COLOR, bgColor)
  lcd.drawFilledRectangle(x, y, w, h, CUSTOM_COLOR)

  -- Draw mode name centered, in black
  -- Adjust text color or size below. SMLSIZE, 0 "normal", MIDSIZE, DBLSIZE (DEFAULT), or XXLSIZE
  local textW, textH = lcd.sizeText(fmName, DBLSIZE)
  local textX = x + (w - textW) // 2
  local textY = y + (h - textH) // 2
  lcd.setColor(CUSTOM_COLOR, BLACK)
  lcd.drawText(textX, textY, fmName, DBLSIZE + CUSTOM_COLOR)
end

return { name="FMDisplay", options={}, create=create, update=update, refresh=refresh }
